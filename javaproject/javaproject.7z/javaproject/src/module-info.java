/**
 * 
 */
/**
 * @author 2110478300003
 *
 */
module javaproject {
}